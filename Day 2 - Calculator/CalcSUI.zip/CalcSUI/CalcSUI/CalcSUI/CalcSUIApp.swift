//
//  CalcSUIApp.swift
//  CalcSUI
//
//  Created by Andrew Thwaites on 26/08/2022.
//

import SwiftUI

@main
struct CalcSUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
