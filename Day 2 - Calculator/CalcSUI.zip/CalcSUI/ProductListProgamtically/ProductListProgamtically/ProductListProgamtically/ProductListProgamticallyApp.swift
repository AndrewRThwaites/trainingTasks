//
//  ProductListProgamticallyApp.swift
//  ProductListProgamtically
//
//  Created by Andrew Thwaites on 29/08/2022.
//

//import SwiftUI
import UIKit

@main
struct ProductListProgamticallyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
