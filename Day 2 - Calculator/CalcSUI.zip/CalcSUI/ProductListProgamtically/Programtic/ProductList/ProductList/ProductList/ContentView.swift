//
//  ContentView.swift
//  ProductList
//
//  Created by Andrew Thwaites on 31/08/2022.
//

/* https://medium.com/ivymobility-developers/creating-simple-tableview-in-swiftui-1f9e8e464782
*/

import SwiftUI

struct ProductDataType: Identifiable {
  let id    : Int
  let productName  : String
  let productDescription : String
  let productImage  : String
  let fav : Bool
}

var dataTypeList = [
    ProductDataType(id: 0, productName: "Nikon D750",
                    productDescription: "Full frame DSLR Camera",
                    productImage : "d750.jpg",
                    fav : true),
    
    ProductDataType(id: 1,
                    productName: "Sony A77ii",
                    productDescription: "APSC enthusist DSLR Camera",
                    productImage : "a77ii.jpg",
                    fav : false),
    ProductDataType(id: 2,
    productName: "Sony a300",
        productDescription: "Entry DSLR Camera",
                    productImage : "a300.jpg",
                    fav : false),
    ProductDataType(id: 3,
    productName: "Nikon D850",
        productDescription: "Full frame DSLR Camera",
                    productImage : "d850.jpg",
                    fav : false),
    ProductDataType(id: 4,
    productName: "Nikon z6",
        productDescription: "Prosumer fullframe Mirroless camera",
                    productImage : "z6.jpg",
                    fav : false),
  ]

/*
struct ProductList: View {
    var aProduct : [ProductDataType]
    var body: some View {
        NavigationView{
        List(aProduct)
        {
            product in ListRow(aProduct : Product)
        }.navigationBarTitle(Text("Products"))
        }
    }
}

struct ListRow: View {
    var eachProduct : Product
    var body some View {
        HStack{
            text(eachProducr.productName)
            Spacer()
            Image("img")
                .resizable()
                .frame(minWidth: 40)
 
            }
    }
}

*/

/*
 D] get images
 A] set constrains of cell elements ****
 e] add images
 B] ability to click on something for fav
 C] modify list to change fav element
 */

struct ContentView: View {
    var body: some View {
        Text("Product List")
            .padding()
        
        
        List(dataTypeList) { dataType in
                  HStack {
                      Image(dataType.productImage)
                       //   .resizable()
                        //  .scaledToFit()
                        
                      VStack(alignment: .leading) {
                      Text(dataType.productName).fontWeight(.bold)
                          //.frame(maxWidth: .infinity)
                      Text(dataType.productDescription)
                              .font(.system(size: 10))
                      }
                  }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
